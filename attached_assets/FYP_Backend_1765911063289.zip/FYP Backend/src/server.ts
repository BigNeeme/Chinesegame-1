import 'dotenv/config';
import Fastify from 'fastify';
import mongoose from 'mongoose';
import { createServer } from 'http';
import { Server } from 'socket.io';

import Game from './models/Game';
import { applyMove } from './logic/applyMove';
import { checkTurnTimeout } from './logic/turns';
import { dealGame } from './logic/dealGame';
import { createGame } from './logic/createGame';

import { register, login, verifyToken } from './logic/auth';

const app = Fastify();

// ==================== MongoDB ====================
mongoose
  .connect(process.env.MONGO_URI as string)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));


// ==================== Server ====================
app.ready().then(() => {
  const httpServer = createServer(app.server);

  const io = new Server(httpServer, {
    cors: { origin: '*' }
  });

  // expose io globally (used by timers)
  (global as any).io = io;

  io.on('connection', (socket) => {
    console.log('Player connected:', socket.id);

    // -------- Register --------
    socket.on('register', async ({ username, password }) => {
      try {
        const user = await register(username, password);
        socket.emit('registerSuccess', {
          userId: user._id,
          username: user.username
        });
      } catch (err: any) {
        socket.emit('authError', err.message);
      }
    });

    // -------- Login --------
    socket.on('login', async ({ username, password }) => {
      try {
        const { user, token } = await login(username, password);
        socket.emit('loginSuccess', {
          userId: user._id,
          username: user.username,
          token
        });
      } catch (err: any) {
        socket.emit('authError', err.message);
      }
    });

    // -------- Logout --------
    socket.on('logout', () => {
      socket.emit('logoutSuccess');
    });

    // -------- Create Game --------
    socket.on('createGame', async ({ token }) => {
      try {
        const decoded: any = verifyToken(token);
        const game = await createGame(decoded.userId);
        socket.join(game._id.toString());
        socket.emit('gameCreated', game);
      } catch (err: any) {
        socket.emit('error', err.message);
      }
    });

    // -------- Join Existing Game --------
    socket.on('joinExistingGame', async ({ token, gameId }) => {
      try {
        const decoded: any = verifyToken(token);
        const playerId = decoded.userId;

        const game: any = await Game.findById(gameId);
        if (!game) throw new Error('Game not found');
        if (game.players.length >= 4) throw new Error('Game full');

        const alreadyJoined = game.players.some(
          (p: any) => p.playerId === playerId
        );

        if (!alreadyJoined) {
          game.players.push({
            playerId,
            isBot: false,
            hand: [],
            hasPassed: false,
            finished: false
          });
          await game.save();
        }

        socket.join(gameId);
        io.to(gameId).emit('gameUpdated', game);
      } catch (err: any) {
        socket.emit('error', err.message);
      }
    });

    // -------- Start Game (Deal Cards) --------
    socket.on('startGame', async ({ token, gameId }) => {
      try {
        verifyToken(token);
        const game = await dealGame(gameId);
        io.to(gameId).emit('gameUpdated', game);
      } catch (err: any) {
        socket.emit('error', err.message);
      }
    });

    // -------- Play Move (PROTECTED) --------
    socket.on('playMove', async ({ token, gameId, playerId, cards }) => {
      try {
        const decoded: any = verifyToken(token);

        if (decoded.userId !== playerId) {
          throw new Error('Unauthorized');
        }

        const game = await applyMove(gameId, playerId, cards);
        io.to(gameId).emit('gameUpdated', game);
      } catch (err: any) {
        socket.emit('moveRejected', err.message);
      }
    });

    socket.on('disconnect', () => {
      console.log('Player disconnected:', socket.id);
    });
  });

  httpServer.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
  });
});

// ==================== TURN TIMER (30s AUTO-PASS) ====================
setInterval(async () => {
  const games: any[] = await Game.find({ status: 'playing' });

  for (const game of games) {
    const updated = await checkTurnTimeout(game._id);
    if (updated) {
      const io = (global as any).io;
      io.to(String(updated._id)).emit('gameUpdated', updated);
    }
  }
}, 1000);

// ==================== GAME CLEANUP ====================
setInterval(async () => {
  const cutoff = new Date(Date.now() - 60 * 60 * 1000); // 1 hour
  await Game.deleteMany({
    status: 'finished',
    archivedAt: { $lte: cutoff }
  });
}, 10 * 60 * 1000);
