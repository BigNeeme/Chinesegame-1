import Game from '../models/Game';

const TURN_LIMIT_MS = 30_000;

export async function checkTurnTimeout(gameId: string) {
  const game: any = await Game.findById(gameId);
  if (!game || game.status !== 'playing') return null;

  const now = Date.now();
  const last = new Date(game.lastActionAt).getTime();

  if (now - last < TURN_LIMIT_MS) return null;

  // AUTO-PASS
  const currentPlayer = game.players[game.currentTurnIndex];
  if (!currentPlayer || currentPlayer.finished) return null;

  game.passedPlayers.push(currentPlayer.playerId);
  currentPlayer.hasPassed = true;

  // Advance turn
  game.currentTurnIndex =
    (game.currentTurnIndex + 1) % game.players.length;

  game.lastActionAt = new Date();

  // If everyone else passed → round reset
  const activePlayers = game.players.filter(
    (p: any) => !p.finished
  ).length;

  if (game.passedPlayers.length >= activePlayers - 1) {
    game.currentSet = null;
    game.passedPlayers = [];
    game.players.forEach((p: any) => (p.hasPassed = false));
    game.status = 'roundReset';
    // Next round starts from last player who played
    // (already enforced elsewhere when next move comes)
  }

  await game.save();
  return game;
}
