import Game from '../models/Game';

export async function createGame(hostId: string) {
  const game = await Game.create({
    status: 'waiting',
    hostId,
    players: [
      {
        playerId: hostId,
        isBot: false,
        hand: [],
        hasPassed: false,
        finished: false
      }
    ],
    currentTurnIndex: 0,
    currentSet: null,
    passedPlayers: [],
    winnerId: null,
    archivedAt: null
  });

  return game;
}
