import { Card } from '../types/card';

const SUITS: Card['suit'][] = ['D', 'C', 'H', 'S'];
const RANKS: Card['rank'][] = [
  3, 4, 5, 6, 7, 8, 9, 10, 'J', 'Q', 'K', 'A', 2
];

export function createDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ rank, suit });
    }
  }
  return deck;
}

export function shuffle(deck: Card[]): Card[] {
  const d = [...deck];
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}
