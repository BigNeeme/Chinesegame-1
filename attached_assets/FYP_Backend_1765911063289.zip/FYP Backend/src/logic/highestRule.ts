import { Card } from '../types/card';
import { compareCards } from './gameLogic';

export function getHighestSingle(hand: Card[]): Card | null {
  if (hand.length === 0) return null;
  return [...hand].sort(compareCards)[hand.length - 1];
}
