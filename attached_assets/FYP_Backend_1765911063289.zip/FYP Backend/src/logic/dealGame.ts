import Game from '../models/Game';
import { createDeck, shuffle } from './deck';
import { compareCards } from './gameLogic';

export async function dealGame(gameId: string) {
  const game: any = await Game.findById(gameId);
  if (!game) throw new Error('Game not found');

  const deck = shuffle(createDeck());

  // deal 13 cards each
  for (let i = 0; i < game.players.length; i++) {
    game.players[i].hand = deck
      .slice(i * 13, (i + 1) * 13)
      .sort(compareCards);

    game.players[i].hasPassed = false;
    game.players[i].finished = false;
  }

  // find 3♦ holder
  const starterIndex = game.players.findIndex((p: any) =>
    p.hand.some((c: any) => c.rank === 3 && c.suit === 'D')
  );

  game.currentTurnIndex = starterIndex;
  game.currentSet = null;
  game.passedPlayers = [];
  game.status = 'playing';
  game.lastActionAt = new Date();

  await game.save();
  return game;
}
