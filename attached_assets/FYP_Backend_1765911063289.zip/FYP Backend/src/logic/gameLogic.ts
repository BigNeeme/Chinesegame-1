import { Card } from '../types/card';
import { HandType } from '../types/game';

/* ------------------ Card Ranking ------------------ */

const RANK_ORDER: (number | string)[] = [
  3, 4, 5, 6, 7, 8, 9, 10,
  'J', 'Q', 'K', 'A', 2
];

const SUIT_ORDER = ['D', 'C', 'H', 'S'];

export function compareCards(a: Card, b: Card): number {
  const rankDiff =
    RANK_ORDER.indexOf(a.rank) - RANK_ORDER.indexOf(b.rank);

  if (rankDiff !== 0) return rankDiff;

  return SUIT_ORDER.indexOf(a.suit) - SUIT_ORDER.indexOf(b.suit);
}

/* ------------------ Hand Validators ------------------ */

export function isSingle(cards: Card[]): boolean {
  return cards.length === 1;
}

export function isDouble(cards: Card[]): boolean {
  return (
    cards.length === 2 &&
    cards[0].rank === cards[1].rank
  );
}

export function isTriple(cards: Card[]): boolean {
  return (
    cards.length === 3 &&
    cards.every(c => c.rank === cards[0].rank)
  );
}

/* ------------------ Hand Type Detection ------------------ */

export function detectHandType(cards: Card[]): HandType | null {
  if (isSingle(cards)) return 'single';
  if (isDouble(cards)) return 'double';
  if (isTriple(cards)) return 'triple';
  if (cards.length === 5) return 'five';

  return null;
}

/* ------------------ Strength Comparison ------------------ */

export function isHigherSingle(a: Card[], b: Card[]): boolean {
  return compareCards(a[0], b[0]) > 0;
}

export function isHigherSameRank(a: Card[], b: Card[]): boolean {
  return compareCards(
    a[a.length - 1],
    b[b.length - 1]
  ) > 0;
}

/* ------------------ Public Move Validator ------------------ */

export function isLegalMove(
  playedCards: Card[],
  currentSet: Card[] | null,
  currentType: HandType | null
): boolean {
  const playedType = detectHandType(playedCards);

  if (!playedType) return false;

  // New round (no set yet)
  if (!currentSet || !currentType) return true;

  // Must match hand type
  if (playedType !== currentType) return false;

  // Compare strength
  switch (playedType) {
    case 'single':
      return isHigherSingle(playedCards, currentSet);

    case 'double':
    case 'triple':
      return isHigherSameRank(playedCards, currentSet);

    case 'five':
  return isHigherFiveCard(playedCards, currentSet);


    default:
      return false;
  }
}
/* ------------------ Helpers ------------------ */

function sortCards(cards: Card[]): Card[] {
  return [...cards].sort(compareCards);
}

function isStraight(cards: Card[]): boolean {
  const sorted = sortCards(cards);
  const ranks = sorted.map(c => RANK_ORDER.indexOf(c.rank));

  // Special case: A2345 not allowed in your rules → skip

  for (let i = 1; i < ranks.length; i++) {
    if (ranks[i] !== ranks[i - 1] + 1) return false;
  }
  return true;
}

function isFlush(cards: Card[]): boolean {
  return cards.every(c => c.suit === cards[0].suit);
}

function getRankCounts(cards: Card[]): Map<any, number> {
  const map = new Map();
  cards.forEach(c => {
    map.set(c.rank, (map.get(c.rank) || 0) + 1);
  });
  return map;
}

/* ------------------ Poker Detection ------------------ */

type PokerHand =
  | 'straight'
  | 'flush'
  | 'fullhouse'
  | 'quads'
  | 'straightflush'
  | 'royalflush';

const POKER_ORDER: PokerHand[] = [
  'straight',
  'flush',
  'fullhouse',
  'quads',
  'straightflush',
  'royalflush'
];

export function detectPokerHand(cards: Card[]): PokerHand | null {
  if (cards.length !== 5) return null;

  const straight = isStraight(cards);
  const flush = isFlush(cards);
  const rankCounts = [...getRankCounts(cards).values()].sort();

  if (straight && flush) {
    const highest = sortCards(cards)[4].rank;
    if (highest === 'A') return 'royalflush';
    return 'straightflush';
  }

  if (rankCounts.join(',') === '1,4') return 'quads';
  if (rankCounts.join(',') === '2,3') return 'fullhouse';
  if (flush) return 'flush';
  if (straight) return 'straight';

  return null;
}
export function isHigherFiveCard(
  played: Card[],
  current: Card[]
): boolean {
  const playedType = detectPokerHand(played);
  const currentType = detectPokerHand(current);

  if (!playedType || !currentType) return false;

  const typeDiff =
    POKER_ORDER.indexOf(playedType) -
    POKER_ORDER.indexOf(currentType);

  if (typeDiff !== 0) return typeDiff > 0;

  // Same type → apply your rules
  if (playedType === 'flush') {
    // suit only
    return (
      SUIT_ORDER.indexOf(played[0].suit) >
      SUIT_ORDER.indexOf(current[0].suit)
    );
  }

  if (playedType === 'straight' || playedType === 'straightflush') {
    const pHigh = sortCards(played)[4];
    const cHigh = sortCards(current)[4];
    return compareCards(pHigh, cHigh) > 0;
  }

  // full house / quads → compare dominant rank
  const pCounts = getRankCounts(played);
  const cCounts = getRankCounts(current);

  const pMain = [...pCounts.entries()].find(e => e[1] > 1)![0];
  const cMain = [...cCounts.entries()].find(e => e[1] > 1)![0];

  return (
    RANK_ORDER.indexOf(pMain) >
    RANK_ORDER.indexOf(cMain)
  );
}
