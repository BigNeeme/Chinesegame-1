import Game from '../models/Game';
import { isLegalMove } from './gameLogic';
import { Card } from '../types/card';
import { HandType } from '../types/game';
import { getHighestSingle } from './highestRule';
import Stats from '../models/Stats';



export async function applyMove(
  gameId: string,
  playerId: string,
  playedCards: Card[]
) {
  const game: any = await Game.findById(gameId);
  if (!game) throw new Error('Game not found');

  const player = game.players.find(
    (p: any) => p.playerId === playerId
  );
  if (!player) throw new Error('Player not in game');

  const currentPlayer = game.players[game.currentTurnIndex];
  if (currentPlayer.playerId !== playerId) {
    throw new Error('Not your turn');
  }

  const legal = isLegalMove(
    playedCards,
    game.currentSet?.cards || null,
    game.currentSet?.type || null
  );

  if (!legal) throw new Error('Illegal move');

  // Remove cards from player's hand
  player.hand = player.hand.filter(
    (c: Card) =>
      !playedCards.some(
        p => p.rank === c.rank && p.suit === c.suit
      )
  );
    if (player.hand.length === 0) {
    player.finished = true;
    game.winnerId = playerId;
    game.status = 'finished';
    game.archivedAt = new Date();

    // -------- Update stats --------
    await Stats.updateOne(
        { playerId },
        { $inc: { wins: 1 } },
        { upsert: true }
    );

    for (const p of game.players) {
        if (p.playerId !== playerId) {
        await Stats.updateOne(
            { playerId: p.playerId },
            { $inc: { losses: 1 } },
            { upsert: true }
        );
        }
    }

  // game is finished → no further turn logic
  await game.save();
  return game;
}
  // Update current set safely
  const newType: HandType =
    game.currentSet?.type ||
    (playedCards.length === 1
      ? 'single'
      : playedCards.length === 2
      ? 'double'
      : playedCards.length === 3
      ? 'triple'
      : 'five');

  game.currentSet = {
    type: newType,
    cards: playedCards,
    playedBy: playerId
  };

  game.passedPlayers = [];
  game.lastActionAt = new Date();

  // Win condition
  if (player.hand.length === 0) {
    player.finished = true;
    game.winnerId = playerId;
    game.status = 'finished';
  }

// HIGHEST RULE
if (player.hand.length === 1) {
  const prevIndex =
    (game.currentTurnIndex - 1 + game.players.length) %
    game.players.length;

  const prevPlayer = game.players[prevIndex];

  if (!prevPlayer.finished && prevPlayer.hand.length > 0) {
    const forcedCard = getHighestSingle(prevPlayer.hand);

    if (forcedCard) {
      // force play as SINGLE
      prevPlayer.hand = prevPlayer.hand.filter(
        (c: Card) =>
          !(c.rank === forcedCard.rank && c.suit === forcedCard.suit)
      );

      game.currentSet = {
        type: 'single',
        cards: [forcedCard],
        playedBy: prevPlayer.playerId
      };

      game.currentTurnIndex =
        (prevIndex + 1) % game.players.length;
    }
  }
}

  // Advance turn
  game.currentTurnIndex =
    (game.currentTurnIndex + 1) % game.players.length;

  await game.save();
  return game;
}
