import * as mongoose from 'mongoose';

const CardSchema = new mongoose.Schema(
  {
    rank: { type: mongoose.Schema.Types.Mixed, required: true },
    suit: {
      type: String,
      enum: ['D', 'C', 'H', 'S'],
      required: true
    }
  },
  { _id: false }
);

const PlayerSchema = new mongoose.Schema(
  {
    playerId: { type: String, required: true },
    isBot: { type: Boolean, default: false },
    hand: { type: [CardSchema], default: [] },
    hasPassed: { type: Boolean, default: false },
    finished: { type: Boolean, default: false }
  },
  { _id: false }
);

const GameSchema = new mongoose.Schema(
  {
    // lobby / lifecycle
    status: {
      type: String,
      enum: ['waiting', 'dealing', 'playing', 'roundReset', 'finished'],
      required: true
    },
    hostId: {
      type: String,
      required: true
    },

    // gameplay
    players: { type: [PlayerSchema], default: [] },
    currentTurnIndex: { type: Number, default: 0 },
    currentSet: {
      type: {
        type: String
      },
      cards: [CardSchema],
      playedBy: String
    },
    passedPlayers: { type: [String], default: [] },
    lastActionAt: { type: Date, default: Date.now },
    winnerId: { type: String, default: null },

    // archival
    archivedAt: { type: Date, default: null }
  },
  { timestamps: true }
);

export default mongoose.model('Game', GameSchema);
