export type Suit = 'D' | 'C' | 'H' | 'S';

export type Rank =
  | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10
  | 'J' | 'Q' | 'K' | 'A' | 2;

export interface Card {
  rank: Rank;
  suit: Suit;
}
