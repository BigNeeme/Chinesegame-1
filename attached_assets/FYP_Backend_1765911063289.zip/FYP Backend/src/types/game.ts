import { Card } from './card';

export type GameStatus =
  | 'waiting'
  | 'dealing'
  | 'playing'
  | 'roundReset'
  | 'finished';

export type HandType =
  | 'single'
  | 'double'
  | 'triple'
  | 'five';

export interface PlayerState {
  playerId: string;
  isBot: boolean;
  hand: Card[];
  hasPassed: boolean;
  finished: boolean;
}

export interface CurrentSet {
  type: HandType;
  cards: Card[];
  playedBy: string;
}

export interface GameState {
  status: GameStatus;
  players: PlayerState[];
  currentTurnIndex: number;
  currentSet: CurrentSet | null;
  passedPlayers: string[];
  lastActionAt: Date;
  winnerId: string | null;
}
